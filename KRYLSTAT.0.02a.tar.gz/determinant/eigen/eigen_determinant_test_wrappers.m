clear all;close all;

nx=10;
nshifts=7;
distance=2;
colouringtype=2;
verbosity=4;
cgTol=1e-5;
cgMaxIter=10000;

Q=modLaplacian(nx,'stat3');
Q=Q+0.1*speye(size(Q));



probe=matlab_wrap_probing_vector(Q,colouringtype,distance,verbosity);

d=eig(full(Q));
minEig=d(1);
maxEig=d(nx);

clear d;

[wsq,dzdt,intConst]=matlab_wrap_compute_shifts(minEig,maxEig,nshifts,verbosity);

ld=2*sum(log(diag(chol(Q))));


ld1=matlab_wrap_eigen_det_app(Q,cgTol,cgMaxIter,distance,3,3);

Q=triu(Q);

ld2=matlab_wrap_det_app_base(Q,probe,wsq,dzdt,intConst,cgTol,cgMaxIter,4);