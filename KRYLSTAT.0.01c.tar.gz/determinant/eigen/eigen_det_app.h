// This file is part of the KRYLSTAT function library
//
// Copyright (C) 2011 Erlend Aune <erlenda@math.ntnu.no>
//
// The KRYLSTAT library is free software; 
// you can redistribute it and/or modify it under the terms 
// of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 3 of the 
// License, or (at your option) any later version.
//
// Alternatively, you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// The KRYLSTAT library is distributed in the 
// hope that it will be useful, but WITHOUT ANY WARRANTY; without
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A
// PARTICULAR PURPOSE. See the GNU Lesser General Public License
// or the GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License and a copy of the GNU General Public License along with
// the KRYLSTAT library. If not, see 
// <http://www.gnu.org/licenses/>.

#ifndef EIGEN_DET_APP_H
#define EIGEN_DET_APP_H

/*! Include openmp */
#include <omp.h>

/*! Including Eigen  */
#include <Eigen/Eigen>
#include <unsupported/Eigen/SparseExtra>

/*! Including what I need from boost */
#include <boost/random.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/mersenne_twister.hpp>

/*! Including the rest of the stuff */
#include "../../cocg_m/basis/monitor.h"
#include "../../cocg_m/eigen/eigen_cocg_m.h"
#include "../../ratApps/sncndn.h"
#include "../../lanczos/eigen/eigen_lanczos.h"

#include "../SpStructCont.h"
#include "../../eigen_pow.h"

/*! Including ColPack stuff */
#include <ColPackHeaders.h>





using namespace Eigen;
using namespace ColPack;

typedef unsigned int int_type;

template <class LinearOperator, class Scalar1, class Derived1>
void logDetApp(const LinearOperator &A, const Scalar1 &min_eig, const Scalar1 &max_eig, 
		 const int_type nshifts, const Scalar1 &cg_tol, const int_type kdist, 
		 Scalar1 &logdet, const MatrixBase<Derived1> margVars);


template <class LinearOperator, class Derived1, class Scalar1>
void logDetMargVar(const LinearOperator &A, const Scalar1 &cgTol, const int_type cgMaxIter, const int_type kdist,
		   Scalar1 &logdet, const MatrixBase<Derived1> margVars);



template <class LinearOperator, class Derived1, class Scalar1>
void logDetMargVar(const LinearOperator &A, const Scalar1 &cgTol, const int_type cgMaxIter, const int_type kdist,
		   Scalar1 &logdet, const MatrixBase<Derived1> margVars)
{
  typedef std::complex<Scalar1> Scalar2;
  Scalar1 pi(3.141592653589793238462643383279L);
  Scalar1 minEig,maxEig;
  Matrix<Scalar1,Dynamic,1> dummyX1(A.cols());
  Matrix<Scalar1,Dynamic,1> dummyX2=Matrix<Scalar1,Dynamic,1>::Zero(A.cols());
  
  boost::normal_distribution<Scalar1> normDist(0,1);
  boost::mt11213b randGen;
  boost::variate_generator<boost::mt11213b, boost::normal_distribution<Scalar1> > randNorm(randGen,normDist);
  
  
  for (int_type jjj=0;jjj<A.rows();++jjj) {dummyX1(jjj)=randNorm();}
  default_monitor<Scalar1> monEig(dummyX1, cgMaxIter, cgTol);
  
  
  eigen_lanc_extremal_eig_mult(A, dummyX1, dummyX2, minEig, maxEig, monEig);
  dummyX1=Matrix<Scalar1,Dynamic,1>::Zero(1);
  dummyX2=Matrix<Scalar1,Dynamic,1>::Zero(1);
  
  //const Scalar1 minEig2(minEig), maxEig2(maxEig);
  
  const int_type nshifts(  static_cast<int>(-1.5*(std::log(maxEig/minEig)+6.)*std::log(cgTol)/(2.*pi*pi))  );
  
  
  std::cout << "nshifts=" << nshifts << "\n";
  
  
  logDetApp(A, minEig, maxEig, nshifts, cgTol, kdist, logdet, margVars);
}


template <class LinearOperator, class Scalar1, class Derived1>
void logDetApp(const LinearOperator &A, const Scalar1 &min_eig, const Scalar1 &max_eig, 
		 const int_type nshifts, const Scalar1 &cg_tol, const int_type kdist, 
		 Scalar1 &logdet, const MatrixBase<Derived1> margVars)
{
  typedef std::complex<Scalar1> Scalar2;
  Scalar1 *intConst = new Scalar1;
  Scalar2 *wsq = new Scalar2[nshifts];
  Scalar2 *dzdt = new Scalar2[nshifts];
  
  logIntPoints(nshifts, min_eig, max_eig, intConst, wsq, dzdt);
  
  Matrix<Scalar2,Dynamic,1> wsqEig(nshifts);
  for(int_type iii=0;iii<nshifts;++iii){wsqEig(iii)=-wsq[iii];} //negative to get right shifts
  
  Matrix<int,Dynamic,1> ProbeVec(A.cols());
  
  {
    LinearOperator B=A;
    eigen_power_sparse(A,kdist,B);
    int *col_indices=B._innerIndexPtr();
    int *row_offsets=B._outerIndexPtr();
    
    SpStructCont<int> SPS(row_offsets,col_indices,A.cols());
  
    // SPS.printSPS();
    GraphColoringInterface * ColOr = new GraphColoringInterface(SRC_MEM_ADOLC, SPS.pptr, SPS.num_rows);
    ColOr->Coloring("NATURAL", "DISTANCE_TWO");
    
    std::vector<int> col_vec;
    ColOr->GetVertexColors(col_vec);
    ColOr->PrintVertexColoringMetrics();
    delete ColOr;
    for (int_type iii=0;iii<A.cols();iii++)
    {
        ProbeVec(iii)=col_vec[iii];
    }
  }
  
  // std::cout << ProbeVec << "\n\n\n\n";
  
  int nCol=ProbeVec.maxCoeff();
  std::cout << "Number of Colours: " << nCol+1 << "\n\n";
#pragma omp parallel for
  for(int iii=0;iii<nCol+1;++iii)
  {
    Matrix<Scalar1,Dynamic,1> probe=Matrix<Scalar1,Dynamic,1>::Zero(A.cols());
    Matrix<Scalar1,Dynamic,1> temp(A.cols());
    Matrix<Scalar2,Dynamic,1> logV=Matrix<Scalar2,Dynamic,1>::Zero(A.cols());
    
    Matrix<Scalar2,Dynamic,Dynamic> x_sh=Matrix<Scalar2,Dynamic,Dynamic>::Zero(A.cols(),nshifts);
    
    for (int jjj=0;jjj<A.cols();++jjj)
    {
      if ( ProbeVec(jjj)==iii )
      {
	probe(jjj)=Scalar1(1);
      }
    }
    
    
    // std::cout << probe << "\n\n";
    
    
    default_monitor<Scalar1> mon(probe,500,cg_tol);
    eigen_cocg_m(A, probe, temp, x_sh, wsqEig, mon);
    
    
    for (int kkk=0;kkk<nshifts;++kkk)
    {
      logV=logV-dzdt[kkk]*x_sh.col(kkk);
    }
    temp=(*intConst)*logV.imag();
    temp=A*temp;
    logdet=logdet+temp.dot(probe);
  }

  
  delete intConst;
  delete[] wsq;
  delete[] dzdt;
}


#endif