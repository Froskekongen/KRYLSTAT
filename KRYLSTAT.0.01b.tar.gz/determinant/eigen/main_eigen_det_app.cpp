#define EIGEN_YES_I_KNOW_SPARSE_MODULE_IS_NOT_STABLE_YET

#include <iostream>
#include "eigen_det_app.h"
#include "../../eigen_pow.h"

using namespace ColPack;
int main()
{
  
  int_type sizeAmat=1000;
  int_type nshifts=12;
  // int_type Nsamples=10;
  
  DynamicSparseMatrix<double> AB(sizeAmat,sizeAmat);
  AB.reserve(3*sizeAmat);
  for (int iii=0;iii<sizeAmat;++iii){AB.insert(iii,iii)=2.1;}
  for (int iii=0;iii<sizeAmat-1;++iii){AB.insert(iii+1,iii)=-1.;}
  for (int iii=0;iii<sizeAmat-1;++iii){AB.insert(iii,iii+1)=-1.;}
  AB.finalize();
  SparseMatrix<double> A(AB);
  // Matrix<double,Dynamic,Dynamic> samples(sizeAmat,Nsamples);
  
  double minEig=0.01,maxEig=5.;
  double cg_tol=1e-4;
  int_type cg_maxiter=2000;
  double logdet=0;
  int_type kdist=10;
  double logdet2;
  
  VectorXd BB(1);
  
  logDetApp(A, minEig, maxEig, nshifts, cg_tol, kdist, logdet,BB);
  logDetMargVar(A, cg_tol, cg_maxiter, kdist, logdet2, BB);
  
  std::cout << "Logdet: " << logdet << "\n\n";
  
  
//   double *intConst = new double;
//   std::complex<double> *wsq = new std::complex<double>[nshifts];
//   std::complex<double> *dzdt = new std::complex<double>[nshifts];
//   
//   logIntPoints(nshifts, minEig, maxEig, intConst, wsq, dzdt);
//   
//   for (int iii=0;iii<nshifts;++iii)
//   {
//     std::cout << "wsq(" << iii<< ")=" << wsq[iii] << "        dzdt(" << iii << ")=" << dzdt[iii] << ")       intConst=" << *intConst << "\n\n";
//   }

//   {
//     int_type powwer=3;
//     SparseMatrix<double> B=A;
//     //B.reserve(6*sizeAmat);
//     eigen_power_sparse(A,powwer,B);
//     
//     int *col_indices=B._innerIndexPtr();
//     int *row_offsets=B._outerIndexPtr();
//   
//     SpStructCont<int> SPS(row_offsets,col_indices,sizeAmat);
//   
//     SPS.printSPS();
//     GraphColoringInterface * ColOr = new GraphColoringInterface(SRC_MEM_ADOLC, SPS.pptr, SPS.num_rows);
//     ColOr->Coloring("NATURAL", "DISTANCE_TWO");
//     ColOr->PrintVertexColoringMetrics();
//     delete ColOr;
//   }
  
  

  return 1;
}