// This file is part of the KRYLSTAT function library
//
// Copyright (C) 2011 Erlend Aune <erlenda@math.ntnu.no>
//
// The KRYLSTAT library is free software; 
// you can redistribute it and/or modify it under the terms 
// of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 3 of the 
// License, or (at your option) any later version.
//
// Alternatively, you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// The KRYLSTAT library is distributed in the 
// hope that it will be useful, but WITHOUT ANY WARRANTY; without
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A
// PARTICULAR PURPOSE. See the GNU Lesser General Public License
// or the GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License and a copy of the GNU General Public License along with
// the KRYLSTAT library. If not, see 
// <http://www.gnu.org/licenses/>.


/*#include <iostream.h> */
#include <string.h> 
/*#include <ColPackHeaders.h>*/

#ifndef SPSTRUCT_H
#define SPSTRUCT_H


template <typename int_type> 
class SpStructCont
{
  public:
    int_type num_rows;
    int_type **pptr;
    int_type nnz;
    // ColPack::GraphColoringInterface *graph;
    
    
    SpStructCont(int_type *row_offsets,int_type *column_indices,int_type nr) : num_rows(nr), pptr(new int_type*[nr]),nnz(row_offsets[nr])
    {
      //int_type **pptr;
      /*this->num_rows=num_rows;
      pptr=new int_type*[num_rows];*/
      
      int_type new_ind=0;
      int_type cur_ind=0;
      int_type lengthRow=0;
      
      /*friend std::ostream& operator<< (std::ostream &out, SpStructCont<int_type> &SpS);*/

  
      int_type tempInd=0;
      for(int_type iii=0;iii<num_rows;iii++)
      {
	cur_ind=row_offsets[iii];
	//std::cout<<cur_ind << "\n";
	new_ind=row_offsets[iii+1];
	lengthRow=(new_ind-cur_ind);
    
	pptr[iii]=new int_type[lengthRow+1];
	pptr[iii][0]=lengthRow;
    
	tempInd=cur_ind;
	for(int_type jjj=1;jjj<=lengthRow;jjj++)
	{
	  pptr[iii][jjj]=column_indices[tempInd];
	  tempInd++;
	}
	//std::cout << pptr[iii][0] << "\n";
      }
      
    }
    
    
    
    ~SpStructCont()
    {
      for(int_type iii=0;iii<num_rows;iii++)
      {
	delete [] pptr[iii];    
      }
      delete [] pptr;
      pptr=0;
    }
    
    
    
    
    void printSPS()
    {
      int_type nonzs=0;
      for(int_type iii=0;iii<this->num_rows;++iii)
      {
	std::cout << "Row number " << iii << ". Number of nonzs: " << this->pptr[iii][0] << ". Columns: ";
	nonzs=this->pptr[iii][0];
	for(int_type jjj=1;jjj<=nonzs;++jjj)
	{
	  std::cout << this->pptr[iii][jjj];
	  if (jjj<nonzs)
	  {
	    std::cout << ", ";
	  }
	}
	std::cout << "\n";
      }
    }
    
    
};





#endif
